import webbrowser
def url():
 webbrowser.open(url)
 webbrowser.get(webbrowser).open(url)